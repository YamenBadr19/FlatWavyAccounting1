name=csharp-body/PositionMonitor.cs
/*
 * PositionMonitor.cs - Tracks position lifecycle
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 * Monitors profit lock and trailing stops
 */

using System;
using cAlgo.API;

namespace cAlgo.Robots
{
    public class PositionMonitor
    {
        private Position _position;
        private bool _profitLocked = false;
        private double _entryPrice;
        private TradeType _tradeType;
        
        
        public PositionMonitor(Position position)
        {
            _position = position;
            _entryPrice = position.EntryPrice;
            _tradeType = position.TradeType;
        }
        
        
        /// <summary>
        /// Check if profit lock should trigger
        /// </summary>
        public bool ShouldTriggerProfitLock(double thresholdUSD)
        {
            if (_profitLocked || _position == null || !_position.IsOpen)
                return false;
            
            return _position.GrossProfitInAccountCurrency >= thresholdUSD;
        }
        
        
        /// <summary>
        /// Lock profit by closing half position
        /// </summary>
        public double LockProfit()
        {
            if (_profitLocked)
                return 0;
            
            double lockedAmount = _position.GrossProfitInAccountCurrency / 2;
            _profitLocked = true;
            
            return lockedAmount;
        }
        
        
        /// <summary>
        /// Move stop loss to break-even
        /// </summary>
        public void MoveToBreakEven()
        {
            if (_position == null || !_position.IsOpen)
                return;
            
            // Set SL to entry price
            _position.ModifyStopLossPrice(_entryPrice);
        }
        
        
        /// <summary>
        /// Update trailing stop
        /// </summary>
        public void UpdateTrailingStop(double currentPrice, int trailingOffsetPips, double pipSize)
        {
            if (!_profitLocked || _position == null)
                return;
            
            double trailingDistance = trailingOffsetPips * pipSize;
            double newSL;
            
            if (_tradeType == TradeType.Buy)
            {
                newSL = currentPrice - trailingDistance;
                if (newSL > _position.StopLossPrice)
                    _position.ModifyStopLossPrice(newSL);
            }
            else
            {
                newSL = currentPrice + trailingDistance;
                if (newSL < _position.StopLossPrice)
                    _position.ModifyStopLossPrice(newSL);
            }
        }
        
        
        public bool IsProfitLocked()
        {
            return _profitLocked;
        }
    }
}