name=csharp-body/Blueprint_cBot.cs
/*
 * BLUEPRINT_cBot.cs - The Execution Body
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 * cTrader cBot for Gold (XAUUSD) trading
 * 
 * UNBREAKABLE RISK RULES:
 * 1. Dynamic Lot Sizing (0.01-0.05)
 * 2. $10 Balance Lock Protocol
 * 3. Trailing Stop Management
 */

using System;
using System.Collections.Generic;
using cAlgo.API;
using cAlgo.API.Indicators;

namespace cAlgo.Robots
{
    [Robot(TimeZone = TimeZoneInfo.Utc, AccessRights = AccessRights.None)]
    public class BlueprintCBot : Robot
    {
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        // CONFIGURATION
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        [Parameter("Min Lot Size", DefaultValue = 0.01)]
        public double MinLotSize { get; set; }
        
        [Parameter("Max Lot Size", DefaultValue = 0.05)]
        public double MaxLotSize { get; set; }
        
        [Parameter("Profit Lock Threshold ($)", DefaultValue = 10)]
        public double ProfitLockThreshold { get; set; }
        
        [Parameter("Trailing Stop Offset (pips)", DefaultValue = 10)]
        public int TrailingStopOffset { get; set; }
        
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        // STATE
        // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        
        private Position _currentPosition;
        private bool _profitLocked = false;
        private double _lockedProfitAmount = 0;
        
        
        protected override void OnStart()
        {
            Print("═══════════════════════════════════════════════════");
            Print("🤖 CTRADERT Blueprint cBot Started");
            Print("📍 Symbol: " + Symbol.Name);
            Print("💰 Account Balance: $" + Account.Balance);
            Print("═══════════════════════════════════════════════════");
        }
        
        
        protected override void OnTick()
        {
            // Check if position is open
            if (_currentPosition != null && _currentPosition.IsOpen)
            {
                // Check profit lock threshold
                CheckProfitLock();
                
                // Manage trailing stop
                ManageTrailingStop();
            }
        }
        
        
        /// <summary>
        /// Execute a new trade signal
        /// </summary>
        public bool ExecuteSignal(string signalType, double entryPrice, double stopLoss, double takeProfit, double lotSize)
        {
            Print($"\n🎯 Executing {signalType} signal");
            Print($"   Entry: {entryPrice}, SL: {stopLoss}, TP: {takeProfit}, Lot: {lotSize}");
            
            // Validate lot size is within allowed range
            if (lotSize < MinLotSize || lotSize > MaxLotSize)
            {
                Print($"❌ BLOCKED: Lot size {lotSize} outside allowed range [{MinLotSize}-{MaxLotSize}]");
                return false;
            }
            
            // Close existing position
            if (_currentPosition != null && _currentPosition.IsOpen)
            {
                Close(_currentPosition);
                Print("⏹️ Previous position closed");
            }
            
            // Execute trade
            try
            {
                if (signalType == "BUY")
                {
                    _currentPosition = ExecuteBuyOrder(entryPrice, stopLoss, takeProfit, lotSize);
                }
                else if (signalType == "SELL")
                {
                    _currentPosition = ExecuteSellOrder(entryPrice, stopLoss, takeProfit, lotSize);
                }
                
                if (_currentPosition != null)
                {
                    _profitLocked = false;
                    _lockedProfitAmount = 0;
                    Print($"✅ Position opened: ID {_currentPosition.Id}");
                    return true;
                }
            }
            catch (Exception ex)
            {
                Print($"❌ Error executing trade: {ex.Message}");
                return false;
            }
            
            return false;
        }
        
        
        private Position ExecuteBuyOrder(double entry, double sl, double tp, double volume)
        {
            var result = ExecuteMarketOrder(TradeType.Buy, Symbol, Symbol.NormalizeVolume(volume), "BUY-SIGNAL", sl, tp);
            return result.IsSuccessful ? result.Position : null;
        }
        
        
        private Position ExecuteSellOrder(double entry, double sl, double tp, double volume)
        {
            var result = ExecuteMarketOrder(TradeType.Sell, Symbol, Symbol.NormalizeVolume(volume), "SELL-SIGNAL", sl, tp);
            return result.IsSuccessful ? result.Position : null;
        }
        
        
        /// <summary>
        /// RULE 2: $10 Balance Lock Protocol
        /// When floating profit reaches $10:
        ///   - Action A: Close 50% of position (lock $5 profit)
        ///   - Action B: Move SL of 50% to Entry Price (risk-free)
        /// </summary>
        private void CheckProfitLock()
        {
            if (_currentPosition == null || !_currentPosition.IsOpen)
                return;
            
            double floatingProfit = _currentPosition.GrossProfitInAccountCurrency;
            
            // Check if profit lock threshold reached
            if (!_profitLocked && floatingProfit >= ProfitLockThreshold)
            {
                Print($"\n💰 PROFIT LOCK TRIGGERED: ${floatingProfit:F2} >= ${ProfitLockThreshold:F2}");
                
                // Action A: Close 50% of position
                double halfVolume = _currentPosition.Volume / 2;
                Print($"📌 Action A: Closing 50% of position ({halfVolume} units)");
                
                var closeResult = Close(_currentPosition, halfVolume);
                if (closeResult.IsSuccessful)
                {
                    _lockedProfitAmount = floatingProfit / 2;
                    Print($"✅ Locked ${_lockedProfitAmount:F2} in cash");
                }
                
                // Action B: Move SL to Entry Price (break-even)
                if (_currentPosition.IsOpen && _currentPosition.Volume > 0)
                {
                    Print($"📌 Action B: Moving SL to Entry Price ({_currentPosition.EntryPrice})");
                    
                    ModifyPosition(_currentPosition, _currentPosition.EntryPrice, _currentPosition.TakeProfit);
                    Print($"✅ Position now RISK-FREE (SL at entry)");
                    
                    _profitLocked = true;
                }
            }
        }
        
        
        /// <summary>
        /// RULE 3: Trailing Stop Management
        /// After break-even lock, activate trailing stop
        /// </summary>
        private void ManageTrailingStop()
        {
            if (_currentPosition == null || !_currentPosition.IsOpen || !_profitLocked)
                return;
            
            double currentPrice = _currentPosition.TradeType == TradeType.Buy ? Symbol.Bid : Symbol.Ask;
            double pipsAboveEntry = (_currentPosition.TradeType == TradeType.Buy ? 
                (currentPrice - _currentPosition.EntryPrice) : 
                (_currentPosition.EntryPrice - currentPrice)) / Symbol.PipSize;
            
            // Move SL up by trailing offset only if price moves favorably
            if (pipsAboveEntry > TrailingStopOffset)
            {
                double newSL = _currentPosition.TradeType == TradeType.Buy ?
                    currentPrice - (TrailingStopOffset * Symbol.PipSize) :
                    currentPrice + (TrailingStopOffset * Symbol.PipSize);
                
                if ((newSL > _currentPosition.StopLoss && _currentPosition.TradeType == TradeType.Buy) ||
                    (newSL < _currentPosition.StopLoss && _currentPosition.TradeType == TradeType.Sell))
                {
                    ModifyPosition(_currentPosition, newSL, _currentPosition.TakeProfit);
                    Print($"🔒 Trailing Stop activated: SL moved to {newSL:F2}");
                }
            }
        }
        
        
        protected override void OnStop()
        {
            // Close any open position on stop
            if (_currentPosition != null && _currentPosition.IsOpen)
            {
                Close(_currentPosition);
                Print("⏹️ Position closed on bot stop");
            }
            
            Print("═══════════════════════════════════════════════════");
            Print("👋 CTRADERT Blueprint cBot Stopped");
            Print("═══════════════════════════════════════════════════");
        }
    }
}