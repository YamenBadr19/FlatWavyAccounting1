name=csharp-body/RiskManager.cs
/*
 * RiskManager.cs - Enforces The Iron Rules
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 * Hardcoded risk constraints that cannot be overridden
 */

using System;

namespace cAlgo.Robots
{
    public class RiskManager
    {
        public const double MIN_LOT_SIZE = 0.01;
        public const double MAX_LOT_SIZE = 0.05;
        public const double PROFIT_LOCK_THRESHOLD = 10.0; // USD
        public const int NEWS_MODE_DURATION = 1800; // seconds (30 min)
        
        
        /// <summary>
        /// Calculate appropriate lot size based on market conditions
        /// </summary>
        public static double CalculateLotSize(
            int confluenceLevel, 
            bool newsMode, 
            double accountBalance,
            double riskPercentage = 0.01)
        {
            double baseLot = MIN_LOT_SIZE;
            
            // Start with minimum during news mode
            if (newsMode)
                return MIN_LOT_SIZE;
            
            // Scale based on confluence level (0-3)
            switch (confluenceLevel)
            {
                case 3: // Full confluence
                    baseLot = MAX_LOT_SIZE;
                    break;
                case 2: // Partial confluence
                    baseLot = 0.03;
                    break;
                case 1: // Weak confluence
                    baseLot = 0.02;
                    break;
                default: // No confluence
                    baseLot = MIN_LOT_SIZE;
                    break;
            }
            
            // Ensure within bounds
            return Math.Max(MIN_LOT_SIZE, Math.Min(MAX_LOT_SIZE, baseLot));
        }
        
        
        /// <summary>
        /// Validate signal meets minimum criteria
        /// </summary>
        public static bool ValidateSignal(
            string signalType,
            double entryPrice,
            double stopLoss,
            double takeProfit)
        {
            // Type validation
            if (signalType != "BUY" && signalType != "SELL")
                return false;
            
            // Price validation
            if (entryPrice <= 0 || stopLoss <= 0 || takeProfit <= 0)
                return false;
            
            // Logic validation
            if (signalType == "BUY")
            {
                // For BUY: SL < Entry < TP
                if (!(stopLoss < entryPrice && entryPrice < takeProfit))
                    return false;
            }
            else // SELL
            {
                // For SELL: TP < Entry < SL
                if (!(takeProfit < entryPrice && entryPrice < stopLoss))
                    return false;
            }
            
            return true;
        }
    }
}