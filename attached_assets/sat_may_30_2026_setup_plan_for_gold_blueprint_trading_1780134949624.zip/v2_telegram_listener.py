name=telegram_listener.py
"""
The Radar: Telegram Userbot Listener & Signal Parser
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Connects to Telegram using MTProto API via Telethon.
Monitors Signal & News folders for Gold (XAUUSD) signals.
Parses regex patterns and streams to market_analyzer.py
"""

import asyncio
import re
import logging
from datetime import datetime
from typing import Optional, Dict, List
from dataclasses import dataclass, asdict
from telethon import TelegramClient, events
import json
import sys

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# CONFIGURATION & LOGGING
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('telegram_listener.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Import configuration
try:
    from config import (
        TELEGRAM_API_ID, TELEGRAM_API_HASH, TELEGRAM_PHONE,
        SIGNALS_FOLDER_ID, NEWS_FOLDER_ID, SESSION_NAME
    )
except ImportError:
    logger.error("❌ config.py not found. Create it with Telegram credentials.")
    sys.exit(1)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# DATA MODELS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@dataclass
class TradingSignal:
    """Parsed Gold Trading Signal"""
    timestamp: str
    signal_type: str
    entry_price: float
    stop_loss: float
    take_profit: float
    source_folder: str
    raw_message: str
    confidence_score: float = 1.0
    
    def to_dict(self) -> Dict:
        return asdict(self)
    
    def to_json(self) -> str:
        return json.dumps(self.to_dict())


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# SIGNAL PARSER (REGEX ENGINE)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class SignalParser:
    """Extracts XAUUSD trading signals using regex patterns."""
    
    PATTERNS = {
        # Format 1: "BUY XAUUSD @ 2450.50, SL: 2445.00, TP: 2460.00"
        'format_1': r'(?P<type>BUY|SELL)\s+(?:XAUUSD|XAU/USD)\s+@\s+(?P<entry>\d+\.?\d*),?\s+(?:SL|Stop\s*Loss):\s*(?P<sl>\d+\.?\d*),?\s+(?:TP|Take\s*Profit):\s*(?P<tp>\d+\.?\d*)',
        
        # Format 2: "BUY\n2450.50\nSL: 2445.00\nTP: 2460.00"
        'format_2': r'(?P<type>BUY|SELL)\s*(?:XAUUSD|XAU/USD)?\s*[\n\r]+(?P<entry>\d+\.?\d*)\s*[\n\r]+(?:SL|Stop\s*Loss):\s*(?P<sl>\d+\.?\d*)\s*[\n\r]+(?:TP|Take\s*Profit):\s*(?P<tp>\d+\.?\d*)',
        
        # Format 3: "XAUUSD\nBUY @ 2450.50\nS/L 2445.00\nT/P 2460.00"
        'format_3': r'(?:XAUUSD|XAU/USD)\s*[\n\r]+(?P<type>BUY|SELL)\s+@\s+(?P<entry>\d+\.?\d*)\s*[\n\r]+(?:S/L|SL|Stop\s*Loss)\s*(?P<sl>\d+\.?\d*)\s*[\n\r]+(?:T/P|TP|Take\s*Profit)\s*(?P<tp>\d+\.?\d*)',
        
        # Format 4: "#BUY 2450.50 SL2445 TP2460"
        'format_4': r'#(?P<type>BUY|SELL)\s+(?P<entry>\d+\.?\d*)\s+SL\s*(?P<sl>\d+\.?\d*)\s+TP\s*(?P<tp>\d+\.?\d*)',
    }
    
    @staticmethod
    def parse_signal(message: str) -> Optional[TradingSignal]:
        """Attempt to parse a signal from message text."""
        message = message.strip()
        
        if 'XAUUSD' not in message.upper() and 'XAU/USD' not in message.upper():
            return None
        
        for pattern_name, pattern in SignalParser.PATTERNS.items():
            match = re.search(pattern, message, re.IGNORECASE | re.MULTILINE)
            
            if match:
                try:
                    signal_type = match.group('type').upper()
                    entry_price = float(match.group('entry'))
                    stop_loss = float(match.group('sl'))
                    take_profit = float(match.group('tp'))
                    
                    # Validation
                    if signal_type == 'BUY':
                        if not (stop_loss < entry_price < take_profit):
                            logger.warning(f"❌ Invalid BUY: SL({stop_loss}) < Entry({entry_price}) < TP({take_profit})")
                            continue
                    else:  # SELL
                        if not (take_profit < entry_price < stop_loss):
                            logger.warning(f"❌ Invalid SELL: TP({take_profit}) < Entry({entry_price}) < SL({stop_loss})")
                            continue
                    
                    logger.info(f"✅ Signal parsed ({pattern_name}): {signal_type} @ {entry_price}")
                    
                    return TradingSignal(
                        timestamp=datetime.utcnow().isoformat(),
                        signal_type=signal_type,
                        entry_price=entry_price,
                        stop_loss=stop_loss,
                        take_profit=take_profit,
                        source_folder="SIGNALS",
                        raw_message=message
                    )
                
                except (ValueError, AttributeError) as e:
                    logger.error(f"❌ Error parsing {pattern_name}: {e}")
                    continue
        
        return None


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# TELEGRAM LISTENER
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class TelegramListener:
    """Connects to Telegram and monitors Signal/News folders."""
    
    def __init__(self):
        self.client = TelegramClient(SESSION_NAME, TELEGRAM_API_ID, TELEGRAM_API_HASH)
        self.signals_queue: List[TradingSignal] = []
        self.news_queue: List[str] = []
        logger.info("🎯 TelegramListener initialized")
    
    async def start(self):
        """Initialize and authenticate with Telegram"""
        await self.client.start(phone=TELEGRAM_PHONE)
        logger.info("✅ Telegram client authenticated")
        
        try:
            signals_entity = await self.client.get_entity(SIGNALS_FOLDER_ID)
            news_entity = await self.client.get_entity(NEWS_FOLDER_ID)
            logger.info(f"✅ Signals folder found")
            logger.info(f"✅ News folder found")
        except Exception as e:
            logger.error(f"❌ Error accessing folders: {e}")
            raise
    
    async def listen_signals(self):
        """Monitor Signals folder"""
        @self.client.on(events.NewMessage(chats=SIGNALS_FOLDER_ID))
        async def handle_signal(event):
            message_text = event.message.message
            logger.info(f"📨 [SIGNALS] New message: {message_text[:80]}...")
            
            signal = SignalParser.parse_signal(message_text)
            if signal:
                self.signals_queue.append(signal)
                logger.info(f"📊 Signal queued: {signal.signal_type} @ {signal.entry_price}")
                await self.stream_signal_to_analyzer(signal)
            else:
                logger.warning("⚠️ Message does not match signal pattern")
        
        logger.info("👂 Listening to Signals folder...")
    
    async def listen_news(self):
        """Monitor News folder"""
        @self.client.on(events.NewMessage(chats=NEWS_FOLDER_ID))
        async def handle_news(event):
            message_text = event.message.message
            logger.info(f"📰 [NEWS] {message_text[:80]}...")
            
            self.news_queue.append(message_text)
            await self.stream_news_to_analyzer(message_text)
        
        logger.info("👂 Listening to News folder...")
    
    async def stream_signal_to_analyzer(self, signal: TradingSignal):
        """Stream signal to market_analyzer.py"""
        logger.info(f"→ Streaming: {signal.to_json()[:100]}...")
        
        # TODO: Implement actual streaming:
        # - Redis queue: r.rpush('signal_queue', signal.to_json())
        # - HTTP API: async with aiohttp.post(...) as resp
        # - Local file: with open('signal_queue.json', 'a') as f
    
    async def stream_news_to_analyzer(self, news_text: str):
        """Stream news to market_analyzer.py"""
        logger.info(f"→ Streaming news: {news_text[:80]}...")
        
        # TODO: Implement actual streaming
    
    async def run(self):
        """Main listener loop"""
        await self.start()
        await self.listen_signals()
        await self.listen_news()
        
        logger.info("━" * 60)
        logger.info("🎯 TELEGRAM LISTENER ACTIVE")
        logger.info("📡 Monitoring: Signals & News folders")
        logger.info("━" * 60)
        
        await self.client.run_until_disconnected()


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# MAIN EXECUTION
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

async def main():
    """Initialize and run the listener"""
    listener = TelegramListener()
    try:
        await listener.run()
    except KeyboardInterrupt:
        logger.info("⏹️ Listener interrupted by user")
    except Exception as e:
        logger.error(f"❌ Critical error: {e}", exc_info=True)
    finally:
        await listener.client.disconnect()
        logger.info("👋 Telegram client disconnected")


if __name__ == "__main__":
    asyncio.run(main())