name=config.py
"""
Configuration file for Telegram credentials and folder IDs.
KEEP THIS PRIVATE - Add to .gitignore
"""

# Telegram API Credentials
# Get from: https://my.telegram.org/apps
TELEGRAM_API_ID = 12345678  # Replace with your API ID
TELEGRAM_API_HASH = "your_api_hash_here"  # Replace with your API Hash
TELEGRAM_PHONE = "+1234567890"  # Your Telegram phone number

# Telegram Folder IDs
# Find these by inspecting folder messages or using Telethon's dialog listing
SIGNALS_FOLDER_ID = 123456789  # Replace with your Signals folder ID
NEWS_FOLDER_ID = 987654321    # Replace with your News folder ID

# Session name (for persistent login)
SESSION_NAME = "gold_trading_session"

# Market Analyzer Connection
ANALYZER_API_URL = "http://localhost:5000"  # Will connect to market_analyzer.py
ANALYZER_API_KEY = "your_secret_key"

# Logging
LOG_LEVEL = "INFO"
LOG_FILE = "telegram_listener.log"