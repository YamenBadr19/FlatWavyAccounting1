name=README.md
# 🏆 CTRADERT Bot - Gold Trading System
## Quantitative Trading Architecture for XAUUSD (Hybrid Python + C# cTrader)

---

## 📖 TABLE OF CONTENTS

1. [System Philosophy](#-system-philosophy)
2. [Architecture Overview](#-architecture-overview)
3. [The Three Analytical Filters](#-the-three-analytical-filters)
4. [The Iron Rules of Risk](#-the-iron-rules-of-risk)
5. [Project Structure](#-project-structure)
6. [Getting Started](#-getting-started)
7. [Deployment Guide](#-deployment-guide)

---

## 🧠 SYSTEM PHILOSOPHY

**"The Separation of Brain and Body"**

This trading system enforces a strict architectural separation:

- **The Brain (Python Core)**: Handles data scraping, AI sentiment parsing, and technical filtering
- **The Body (C# cBot)**: Handles high-speed execution and uncompromisable risk management

This design ensures:
- ✅ **Analysis is never constrained by execution speed**
- ✅ **Execution is never influenced by analysis delays**
- ✅ **Risk management cannot be overridden by logic errors**

---

## 🔧 ARCHITECTURE OVERVIEW
