name=python-brain/market_analyzer.py
"""
The Brain: Market Analyzer - AI Sentiment & Technical Filters
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Receives signals from telegram_listener.py
Applies three strict filtering gates:
1. AI News Sentiment Analysis
2. Pivot Points (Support/Resistance)
3. RSI Momentum Filter

Only validated signals are sent to C# cBot for execution.
"""

import logging
import json
from datetime import datetime, timedelta
from typing import Optional, Dict, Tuple
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# ENUMS & DATA MODELS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class SentimentType(Enum):
    """Market sentiment classification"""
    BULLISH = "BULLISH"
    BEARISH = "BEARISH"
    VOLATILE = "VOLATILE"
    NEUTRAL = "NEUTRAL"


class FilterGate(Enum):
    """Signal validation gate status"""
    PASS = "PASS"
    BLOCK = "BLOCK"
    WARN = "WARN"


@dataclass
class MarketCondition:
    """Current market conditions snapshot"""
    timestamp: str
    news_mode: bool
    news_sentiment: SentimentType
    pivot: float
    resistance_1: float
    support_1: float
    rsi_14: float
    atr: float
    confluence_level: int  # 0-3 (how many filters align)


@dataclass
class FilterResult:
    """Result of each filter gate"""
    gate_name: str
    status: FilterGate
    reason: str
    confluence_score: float  # 0-1


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# FILTER 1: AI NEWS SENTIMENT
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class NewsSentimentFilter:
    """
    Analyzes incoming news for Gold (XAUUSD) sentiment.
    Triggers News_Mode during high-impact events.
    """
    
    # High-impact events that trigger News_Mode
    HIGH_IMPACT_KEYWORDS = [
        'FOMC', 'Federal Reserve', 'Interest Rate', 'Inflation',
        'CPI', 'PPI', 'NFP', 'Employment', 'GDP', 'Geopolitical',
        'War', 'Sanctions', 'Tariffs', 'Trade', 'Recession',
        'Bank', 'Crisis', 'Default', 'Debt', 'Currency Crisis'
    ]
    
    # Bullish for Gold (USD weakness)
    BULLISH_KEYWORDS = [
        'USD weak', 'dollar weakness', 'inflation up', 'rate cut',
        'safe haven', 'geopolitical risk', 'crisis', 'war',
        'tensions', 'uncertainty', 'economic slowdown'
    ]
    
    # Bearish for Gold (USD strength)
    BEARISH_KEYWORDS = [
        'dollar strong', 'rate hike', 'hawkish', 'growth',
        'inflation down', 'deflation', 'risk-on', 'strong economy',
        'employment strong', 'GDP growth'
    ]
    
    def __init__(self):
        self.news_mode = False
        self.news_mode_start = None
        self.news_mode_end = None
        logger.info("🧠 NewsSentimentFilter initialized")
    
    def analyze(self, news_text: str) -> Tuple[SentimentType, bool, str]:
        """
        Analyze news text for sentiment.
        Returns: (Sentiment, News_Mode_Active, Reason)
        """
        news_upper = news_text.upper()
        
        # Check for high-impact event
        high_impact = any(keyword in news_upper for keyword in self.HIGH_IMPACT_KEYWORDS)
        
        if high_impact:
            self.news_mode = True
            self.news_mode_start = datetime.utcnow()
            self.news_mode_end = self.news_mode_start + timedelta(minutes=30)
            logger.info(f"🔴 NEWS_MODE ACTIVATED for 30 minutes")
        
        # Determine sentiment
        bullish_count = sum(1 for kw in self.BULLISH_KEYWORDS if kw.upper() in news_upper)
        bearish_count = sum(1 for kw in self.BEARISH_KEYWORDS if kw.upper() in news_upper)
        
        if bullish_count > bearish_count:
            sentiment = SentimentType.BULLISH
            reason = f"Bullish keywords detected ({bullish_count} mentions)"
        elif bearish_count > bullish_count:
            sentiment = SentimentType.BEARISH
            reason = f"Bearish keywords detected ({bearish_count} mentions)"
        elif high_impact:
            sentiment = SentimentType.VOLATILE
            reason = "High-impact event detected (volatile market expected)"
        else:
            sentiment = SentimentType.NEUTRAL
            reason = "No significant sentiment signals"
        
        return sentiment, self.news_mode, reason
    
    def is_news_mode_active(self) -> bool:
        """Check if News_Mode is still active"""
        if not self.news_mode:
            return False
        
        if datetime.utcnow() > self.news_mode_end:
            self.news_mode = False
            logger.info(f"🟢 NEWS_MODE DEACTIVATED")
            return False
        
        return True


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# FILTER 2: PIVOT POINTS (Support/Resistance)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class PivotPointFilter:
    """
    Calculates institutional daily zones using pivot points.
    Validates entries against S1/R1 levels.
    """
    
    @staticmethod
    def calculate_pivots(high: float, low: float, close: float) -> Dict[str, float]:
        """
        Calculate pivot points from previous day's candlestick.
        
        Formulas:
        Pivot = (H + L + C) / 3
        R1 = (2 × Pivot) - Low
        S1 = (2 × Pivot) - High
        """
        pivot = (high + low + close) / 3
        r1 = (2 * pivot) - low
        s1 = (2 * pivot) - high
        
        return {
            'pivot': pivot,
            'r1': r1,
            's1': s1
        }
    
    @staticmethod
    def validate_buy_entry(entry_price: float, s1: float, r1: float) -> Tuple[FilterGate, str, float]:
        """
        Validate BUY entry against pivot levels.
        
        ✅ PASS: Entry near S1 (support bounce)
        ⚠️ WARN: Entry in neutral zone
        ❌ BLOCK: Entry near R1 (overextended)
        """
        distance_to_s1 = abs(entry_price - s1)
        distance_to_r1 = abs(entry_price - r1)
        
        # Overextended near R1 - BLOCK
        if distance_to_r1 < 5:  # Within 5 pips of R1
            return FilterGate.BLOCK, f"Entry overextended near R1 ({distance_to_r1:.2f} pips away)", 0.0
        
        # Strong confluence at S1 - PASS
        if distance_to_s1 < 5:  # Within 5 pips of S1
            return FilterGate.PASS, f"Strong BUY confluence at S1 bounce ({distance_to_s1:.2f} pips away)", 0.9
        
        # Neutral zone - WARN
        return FilterGate.WARN, f"Entry in neutral zone (S1 gap: {distance_to_s1:.2f}, R1 gap: {distance_to_r1:.2f})", 0.5
    
    @staticmethod
    def validate_sell_entry(entry_price: float, s1: float, r1: float) -> Tuple[FilterGate, str, float]:
        """
        Validate SELL entry against pivot levels.
        
        ✅ PASS: Entry near R1 (resistance rejection)
        ⚠️ WARN: Entry in neutral zone
        ❌ BLOCK: Entry near S1 (oversold)
        """
        distance_to_s1 = abs(entry_price - s1)
        distance_to_r1 = abs(entry_price - r1)
        
        # Collapsed near S1 - BLOCK
        if distance_to_s1 < 5:  # Within 5 pips of S1
            return FilterGate.BLOCK, f"Entry oversold near S1 ({distance_to_s1:.2f} pips away)", 0.0
        
        # Strong confluence at R1 - PASS
        if distance_to_r1 < 5:  # Within 5 pips of R1
            return FilterGate.PASS, f"Strong SELL confluence at R1 rejection ({distance_to_r1:.2f} pips away)", 0.9
        
        # Neutral zone - WARN
        return FilterGate.WARN, f"Entry in neutral zone (R1 gap: {distance_to_r1:.2f}, S1 gap: {distance_to_s1:.2f})", 0.5


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# FILTER 3: RSI MOMENTUM
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class RSIFilter:
    """
    Momentum filter using Relative Strength Index (14-period).
    Prevents buying overbought or selling oversold markets.
    """
    
    OVERBOUGHT = 75
    OVERSOLD = 25
    
    @staticmethod
    def validate_buy(rsi: float) -> Tuple[FilterGate, str, float]:
        """
        Validate BUY signal against RSI.
        
        ✅ PASS: RSI < 75 (not overbought)
        ❌ BLOCK: RSI > 75 (overbought)
        """
        if rsi > RSIFilter.OVERBOUGHT:
            return FilterGate.BLOCK, f"Market overbought (RSI: {rsi:.2f} > 75)", 0.0
        elif rsi < RSIFilter.OVERSOLD:
            return FilterGate.PASS, f"Market oversold, strong BUY setup (RSI: {rsi:.2f} < 25)", 0.9
        else:
            confluence = (100 - rsi) / 100  # Higher confluence as RSI approaches 25
            reason = f"Neutral momentum zone (RSI: {rsi:.2f})"
            return FilterGate.PASS, reason, confluence
    
    @staticmethod
    def validate_sell(rsi: float) -> Tuple[FilterGate, str, float]:
        """
        Validate SELL signal against RSI.
        
        ✅ PASS: RSI > 25 (not oversold)
        ❌ BLOCK: RSI < 25 (oversold)
        """
        if rsi < RSIFilter.OVERSOLD:
            return FilterGate.BLOCK, f"Market oversold (RSI: {rsi:.2f} < 25)", 0.0
        elif rsi > RSIFilter.OVERBOUGHT:
            return FilterGate.PASS, f"Market overbought, strong SELL setup (RSI: {rsi:.2f} > 75)", 0.9
        else:
            confluence = rsi / 100  # Higher confluence as RSI approaches 75
            reason = f"Neutral momentum zone (RSI: {rsi:.2f})"
            return FilterGate.PASS, reason, confluence


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# MARKET ANALYZER (Main Class)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class MarketAnalyzer:
    """
    Main analyzer class that applies all three filters.
    Validates signals before sending to C# cBot.
    """
    
    def __init__(self):
        self.sentiment_filter = NewsSentimentFilter()
        self.pivot_filter = PivotPointFilter()
        self.rsi_filter = RSIFilter()
        logger.info("🧠 MarketAnalyzer initialized with all filters")
    
    def validate_signal(self, signal: Dict, market_data: Dict) -> Tuple[bool, Dict]:
        """
        Apply all three filters to validate a signal.
        
        Returns: (Is_Valid, Validation_Details)
        """
        signal_type = signal.get('signal_type')
        entry_price = signal.get('entry_price')
        
        validation_results = {
            'signal_type': signal_type,
            'entry_price': entry_price,
            'timestamp': datetime.utcnow().isoformat(),
            'filters': [],
            'confluence_level': 0,
            'final_decision': 'PENDING'
        }
        
        # FILTER 1: News Sentiment
        news_mode_active = self.sentiment_filter.is_news_mode_active()
        sentiment_type, _, sentiment_reason = self.sentiment_filter.analyze("")
        
        news_result = FilterResult(
            gate_name="News Sentiment",
            status=FilterGate.PASS if not news_mode_active else FilterGate.WARN,
            reason=sentiment_reason,
            confluence_score=0.5 if news_mode_active else 1.0
        )
        validation_results['filters'].append({
            'name': news_result.gate_name,
            'status': news_result.status.value,
            'reason': news_result.reason,
            'confluence': news_result.confluence_score,
            'news_mode': news_mode_active
        })
        
        # FILTER 2: Pivot Points
        pivots = self.pivot_filter.calculate_pivots(
            market_data.get('high', 0),
            market_data.get('low', 0),
            market_data.get('close', 0)
        )
        
        if signal_type == 'BUY':
            pivot_status, pivot_reason, pivot_confidence = self.pivot_filter.validate_buy_entry(
                entry_price, pivots['s1'], pivots['r1']
            )
        else:
            pivot_status, pivot_reason, pivot_confidence = self.pivot_filter.validate_sell_entry(
                entry_price, pivots['s1'], pivots['r1']
            )
        
        validation_results['filters'].append({
            'name': 'Pivot Points',
            'status': pivot_status.value,
            'reason': pivot_reason,
            'confluence': pivot_confidence,
            'pivots': pivots
        })
        
        # FILTER 3: RSI Momentum
        rsi = market_data.get('rsi_14', 50)
        
        if signal_type == 'BUY':
            rsi_status, rsi_reason, rsi_confidence = self.rsi_filter.validate_buy(rsi)
        else:
            rsi_status, rsi_reason, rsi_confidence = self.rsi_filter.validate_sell(rsi)
        
        validation_results['filters'].append({
            'name': 'RSI Momentum',
            'status': rsi_status.value,
            'reason': rsi_reason,
            'confluence': rsi_confidence,
            'rsi_14': rsi
        })
        
        # FINAL DECISION
        gate_results = [news_result.status, pivot_status, rsi_status]
        block_count = sum(1 for r in gate_results if r == FilterGate.BLOCK)
        pass_count = sum(1 for r in gate_results if r == FilterGate.PASS)
        
        # Calculate confluence level (0-3)
        confluence_level = 0
        if pivot_status == FilterGate.PASS:
            confluence_level += 1
        if rsi_status == FilterGate.PASS:
            confluence_level += 1
        if not news_mode_active:
            confluence_level += 1
        
        validation_results['confluence_level'] = confluence_level
        
        # Decision logic
        if block_count > 0:
            validation_results['final_decision'] = 'BLOCK'
            is_valid = False
        elif pass_count >= 2:
            validation_results['final_decision'] = 'EXECUTE'
            is_valid = True
        else:
            validation_results['final_decision'] = 'CAUTION'
            is_valid = False
        
        logger.info(f"📊 Signal Validation: {signal_type} @ {entry_price} → {validation_results['final_decision']}")
        
        return is_valid, validation_results


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# EXAMPLE USAGE
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

if __name__ == "__main__":
    # Initialize analyzer
    analyzer = MarketAnalyzer()
    
    # Example signal
    test_signal = {
        'signal_type': 'BUY',
        'entry_price': 2449.50,
        'stop_loss': 2445.00,
        'take_profit': 2460.00
    }
    
    # Example market data
    test_market = {
        'high': 2455.00,
        'low': 2445.00,
        'close': 2450.00,
        'rsi_14': 35
    }
    
    # Validate
    is_valid, results = analyzer.validate_signal(test_signal, test_market)
    print(json.dumps(results, indent=2))