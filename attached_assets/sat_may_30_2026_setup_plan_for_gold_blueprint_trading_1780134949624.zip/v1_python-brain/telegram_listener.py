name=python-brain/telegram_listener.py
"""
The Radar: Telegram Userbot Listener & Signal Parser
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Connects to Telegram using MTProto API via Telethon.
Monitors Signal & News folders for Gold (XAUUSD) signals.
Parses regex patterns and streams to market_analyzer.py
"""

import asyncio
import re
import logging
from datetime import datetime
from typing import Optional, Dict, List
from dataclasses import dataclass, asdict
from telethon import TelegramClient, events
import json
import sys
import os

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# LOGGING SETUP
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

os.makedirs('logs', exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/telegram_listener.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# IMPORT CONFIG
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

try:
    from config import (
        TELEGRAM_API_ID, TELEGRAM_API_HASH, TELEGRAM_PHONE,
        SIGNALS_FOLDER_ID, NEWS_FOLDER_ID, SESSION_NAME
    )
except ImportError:
    logger.error("❌ config.py not found or incomplete")
    logger.error("Please create config.py with your Telegram credentials")
    sys.exit(1)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# DATA MODELS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@dataclass
class TradingSignal:
    """Parsed Gold Trading Signal"""
    timestamp: str
    signal_type: str  # BUY or SELL
    entry_price: float
    stop_loss: float
    take_profit: float
    source_folder: str
    raw_message: str
    confidence_score: float = 1.0
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization"""
        return asdict(self)
    
    def to_json(self) -> str:
        """Convert to JSON string"""
        return json.dumps(self.to_dict())


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# SIGNAL PARSER (REGEX ENGINE)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class SignalParser:
    """
    Extracts XAUUSD trading signals using regex patterns.
    Matches multiple signal formats for flexibility.
    """
    
    # Multiple regex patterns for different signal formats
    PATTERNS = {
        # Format 1: "BUY XAUUSD @ 2450.50, SL: 2445.00, TP: 2460.00"
        'format_1': r'(?P<type>BUY|SELL)\s+(?:XAUUSD|XAU/USD)\s+@\s+(?P<entry>\d+\.?\d*),?\s+(?:SL|Stop\s*Loss):\s*(?P<sl>\d+\.?\d*),?\s+(?:TP|Take\s*Profit):\s*(?P<tp>\d+\.?\d*)',
        
        # Format 2: Multi-line format
        'format_2': r'(?P<type>BUY|SELL)\s*(?:XAUUSD|XAU/USD)?\s*[\n\r]+(?P<entry>\d+\.?\d*)\s*[\n\r]+(?:SL|Stop\s*Loss):\s*(?P<sl>\d+\.?\d*)\s*[\n\r]+(?:TP|Take\s*Profit):\s*(?P<tp>\d+\.?\d*)',
        
        # Format 3: Alternative layout
        'format_3': r'(?:XAUUSD|XAU/USD)\s*[\n\r]+(?P<type>BUY|SELL)\s+@\s+(?P<entry>\d+\.?\d*)\s*[\n\r]+(?:S/L|SL|Stop\s*Loss)\s*(?P<sl>\d+\.?\d*)\s*[\n\r]+(?:T/P|TP|Take\s*Profit)\s*(?P<tp>\d+\.?\d*)',
        
        # Format 4: Concise format
        'format_4': r'#(?P<type>BUY|SELL)\s+(?P<entry>\d+\.?\d*)\s+SL\s*(?P<sl>\d+\.?\d*)\s+TP\s*(?P<tp>\d+\.?\d*)',
    }
    
    @staticmethod
    def parse_signal(message: str) -> Optional[TradingSignal]:
        """Attempt to parse a signal from message text."""
        message = message.strip()
        
        # Check if message contains XAUUSD reference
        if 'XAUUSD' not in message.upper() and 'XAU/USD' not in message.upper():
            return None
        
        # Try each regex pattern
        for pattern_name, pattern in SignalParser.PATTERNS.items():
            match = re.search(pattern, message, re.IGNORECASE | re.MULTILINE)
            
            if match:
                try:
                    signal_type = match.group('type').upper()
                    entry_price = float(match.group('entry'))
                    stop_loss = float(match.group('sl'))
                    take_profit = float(match.group('tp'))
                    
                    # Validation: Check logic
                    if signal_type == 'BUY':
                        if not (stop_loss < entry_price < take_profit):
                            logger.warning(f"❌ Invalid BUY: SL({stop_loss}) < Entry({entry_price}) < TP({take_profit})")
                            continue
                    else:  # SELL
                        if not (take_profit < entry_price < stop_loss):
                            logger.warning(f"❌ Invalid SELL: TP({take_profit}) < Entry({entry_price}) < SL({stop_loss})")
                            continue
                    
                    logger.info(f"✅ Signal parsed ({pattern_name}): {signal_type} @ {entry_price}")
                    
                    return TradingSignal(
                        timestamp=datetime.utcnow().isoformat(),
                        signal_type=signal_type,
                        entry_price=entry_price,
                        stop_loss=stop_loss,
                        take_profit=take_profit,
                        source_folder="SIGNALS",
                        raw_message=message
                    )
                
                except (ValueError, AttributeError) as e:
                    logger.error(f"❌ Error parsing {pattern_name}: {e}")
                    continue
        
        return None


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# TELEGRAM LISTENER CLASS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class TelegramListener:
    """
    Connects to Telegram and monitors Signal/News folders.
    Parses signals and streams to market_analyzer.py.
    """
    
    def __init__(self):
        self.client = TelegramClient(SESSION_NAME, TELEGRAM_API_ID, TELEGRAM_API_HASH)
        self.signals_queue: List[TradingSignal] = []
        self.news_queue: List[str] = []
        logger.info("🎯 TelegramListener initialized")
    
    async def start(self):
        """Authenticate with Telegram"""
        logger.info("🔐 Starting Telegram authentication...")
        await self.client.start(phone=TELEGRAM_PHONE)
        logger.info("✅ Telegram client authenticated")
        
        # Verify folder accessibility
        try:
            signals_entity = await self.client.get_entity(SIGNALS_FOLDER_ID)
            news_entity = await self.client.get_entity(NEWS_FOLDER_ID)
            logger.info(f"✅ Signals folder accessible")
            logger.info(f"✅ News folder accessible")
        except Exception as e:
            logger.error(f"❌ Error accessing folders: {e}")
            raise
    
    async def listen_signals(self):
        """Monitor Signals folder for new messages"""
        @self.client.on(events.NewMessage(chats=SIGNALS_FOLDER_ID))
        async def handle_signal(event):
            message_text = event.message.message
            logger.info(f"📨 [SIGNALS] New message received")
            logger.info(f"Content: {message_text[:100]}...")
            
            # Parse signal using regex
            signal = SignalParser.parse_signal(message_text)
            
            if signal:
                self.signals_queue.append(signal)
                logger.info(f"📊 Signal queued: {signal.signal_type} @ {signal.entry_price}")
                await self.stream_signal_to_analyzer(signal)
            else:
                logger.warning("⚠️ Message does not match any signal pattern")
        
        logger.info("👂 Listening to Signals folder...")
    
    async def listen_news(self):
        """Monitor News folder for breaking news"""
        @self.client.on(events.NewMessage(chats=NEWS_FOLDER_ID))
        async def handle_news(event):
            message_text = event.message.message
            logger.info(f"📰 [NEWS] Breaking news received")
            logger.info(f"Content: {message_text[:100]}...")
            
            self.news_queue.append(message_text)
            await self.stream_news_to_analyzer(message_text)
        
        logger.info("👂 Listening to News folder...")
    
    async def stream_signal_to_analyzer(self, signal: TradingSignal):
        """
        Stream parsed signal to market_analyzer.py
        
        PLACEHOLDER: Implement with:
        - Redis queue: r.rpush('signal_queue', signal.to_json())
        - HTTP API: aiohttp POST to analyzer endpoint
        - WebSocket: Send to cTrader webhook
        """
        logger.info(f"→ Streaming signal: {signal.to_json()[:80]}...")
        
        # TODO: Replace with actual implementation
        # Example Redis:
        # import redis
        # r = redis.Redis(host='localhost', port=6379, db=0)
        # r.rpush('signal_queue', signal.to_json())
        
        # Example HTTP:
        # import aiohttp
        # async with aiohttp.ClientSession() as session:
        #     async with session.post('http://localhost:5000/signal', json=signal.to_dict()) as resp:
        #         logger.info(f"Response: {await resp.text()}")
    
    async def stream_news_to_analyzer(self, news_text: str):
        """
        Stream news text to market_analyzer.py for sentiment analysis
        
        PLACEHOLDER: Implement with actual streaming mechanism
        """
        logger.info(f"→ Streaming news: {news_text[:80]}...")
        
        # TODO: Replace with actual implementation
    
    async def run(self):
        """Main listener loop"""
        await self.start()
        await self.listen_signals()
        await self.listen_news()
        
        logger.info("━" * 70)
        logger.info("🎯 TELEGRAM LISTENER ACTIVE")
        logger.info("📡 Monitoring: Signals & News folders")
        logger.info("⏰ Listening for incoming messages...")
        logger.info("━" * 70)
        
        # Keep listener running indefinitely
        await self.client.run_until_disconnected()


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# MAIN EXECUTION
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

async def main():
    """Initialize and run the Telegram listener"""
    listener = TelegramListener()
    try:
        await listener.run()
    except KeyboardInterrupt:
        logger.info("⏹️ Listener interrupted by user (Ctrl+C)")
    except Exception as e:
        logger.error(f"❌ Critical error: {e}", exc_info=True)
    finally:
        await listener.client.disconnect()
        logger.info("👋 Telegram client disconnected")
        logger.info("Shutdown complete")


if __name__ == "__main__":
    logger.info("╔════════════════════════════════════════════════════════════════════╗")
    logger.info("║     CTRADERT BOT - TELEGRAM LISTENER (Gold XAUUSD)                 ║")
    logger.info("║     System Specification: Separation of Brain & Body               ║")
    logger.info("╚════════════════════════════════════════════════════════════════════╝")
    logger.info("")
    
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Application terminated by user")