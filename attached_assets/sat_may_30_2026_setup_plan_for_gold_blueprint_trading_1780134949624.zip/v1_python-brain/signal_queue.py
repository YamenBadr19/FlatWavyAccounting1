name=python-brain/signal_queue.py
"""
Signal Queue: Data Pipeline Bridge
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Manages the queue of validated signals flowing from:
- Telegram Listener → Market Analyzer → C# cBot

Currently uses in-memory queue and file logging.
Can be extended to use Redis, Celery, or message brokers.
"""

import json
import logging
from typing import List, Optional
from datetime import datetime
from dataclasses import dataclass, asdict

logger = logging.getLogger(__name__)


@dataclass
class ValidatedSignal:
    """Signal after passing all three filters"""
    timestamp: str
    signal_type: str
    entry_price: float
    stop_loss: float
    take_profit: float
    lot_size: float  # 0.01 - 0.05 based on confluence
    confluence_level: int  # 0-3
    confidence_score: float  # 0-1
    is_ready_for_execution: bool


class SignalQueue:
    """In-memory signal queue with file persistence"""
    
    def __init__(self, queue_file: str = "signal_queue.log"):
        self.queue: List[ValidatedSignal] = []
        self.queue_file = queue_file
        logger.info(f"📤 SignalQueue initialized (file: {queue_file})")
    
    def enqueue(self, signal: ValidatedSignal):
        """Add validated signal to queue"""
        self.queue.append(signal)
        self._log_to_file(signal)
        logger.info(f"✅ Signal enqueued: {signal.signal_type} @ {signal.entry_price} (Lot: {signal.lot_size})")
    
    def dequeue(self) -> Optional[ValidatedSignal]:
        """Remove and return first signal from queue"""
        if len(self.queue) > 0:
            signal = self.queue.pop(0)
            logger.info(f"📤 Signal dequeued: {signal.signal_type}")
            return signal
        return None
    
    def peek(self) -> Optional[ValidatedSignal]:
        """View first signal without removing"""
        return self.queue[0] if len(self.queue) > 0 else None
    
    def queue_length(self) -> int:
        """Current queue size"""
        return len(self.queue)
    
    def _log_to_file(self, signal: ValidatedSignal):
        """Persist signal to file for audit trail"""
        with open(self.queue_file, 'a') as f:
            f.write(json.dumps(asdict(signal)) + '\n')
    
    def get_history(self, limit: int = 10) -> List[ValidatedSignal]:
        """Get last N signals from file"""
        signals = []
        try:
            with open(self.queue_file, 'r') as f:
                lines = f.readlines()[-limit:]
                for line in lines:
                    data = json.loads(line)
                    signals.append(ValidatedSignal(**data))
        except FileNotFoundError:
            logger.warning("Queue history file not found")
        return signals


# Example usage
if __name__ == "__main__":
    queue = SignalQueue()
    
    # Example validated signal
    signal = ValidatedSignal(
        timestamp=datetime.utcnow().isoformat(),
        signal_type="BUY",
        entry_price=2449.50,
        stop_loss=2445.00,
        take_profit=2460.00,
        lot_size=0.03,
        confluence_level=3,
        confidence_score=0.95,
        is_ready_for_execution=True
    )
    
    queue.enqueue(signal)
    print(f"Queue size: {queue.queue_length()}")