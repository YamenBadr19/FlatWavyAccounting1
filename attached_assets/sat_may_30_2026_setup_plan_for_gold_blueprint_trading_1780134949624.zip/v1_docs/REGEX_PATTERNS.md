name=docs/REGEX_PATTERNS.md
# 📋 Signal Parsing - Regex Patterns

## Supported Signal Formats

The telegram_listener.py supports 4 different signal formats:

---

### Format 1: Inline Format
**Pattern**: Single line with all parameters

```
BUY XAUUSD @ 2450.50, SL: 2445.00, TP: 2460.00
SELL XAUUSD @ 2450.50, SL: 2455.00, TP: 2440.00
```

**Regex**:
```regex
(?P<type>BUY|SELL)\s+(?:XAUUSD|XAU/USD)\s+@\s+(?P<entry>\d+\.?\d*),?\s+(?:SL|Stop\s*Loss):\s*(?P<sl>\d+\.?\d*),?\s+(?:TP|Take\s*Profit):\s*(?P<tp>\d+\.?\d*)
```

**Example Matches**:
- ✅ `BUY XAUUSD @ 2450.50, SL: 2445, TP: 2460`
- ✅ `SELL XAU/USD @ 2450.50, Stop Loss: 2455, Take Profit: 2440`

---

### Format 2: Multi-Line Format
**Pattern**: Each parameter on separate line

```
BUY
2450.50
SL: 2445.00
TP: 2460.00
```

**Regex**:
```regex
(?P<type>BUY|SELL)\s*(?:XAUUSD|XAU/USD)?\s*[\n\r]+(?P<entry>\d+\.?\d*)\s*[\n\r]+(?:SL|Stop\s*Loss):\s*(?P<sl>\d+\.?\d*)\s*[\n\r]+(?:TP|Take\s*Profit):\s*(?P<tp>\d+\.?\d*)
```

**Example Matches**:
```
✅
BUY
2450.50
SL: 2445.00
TP: 2460.00

✅
SELL XAUUSD
2450.50
Stop Loss: 2455.00
Take Profit: 2440.00
```

---

### Format 3: Alternative Layout
**Pattern**: Symbol first, then signal details

```
XAUUSD
BUY @ 2450.50
S/L 2445.00
T/P 2460.00
```

**Regex**:
```regex
(?:XAUUSD|XAU/USD)\s*[\n\r]+(?P<type>BUY|SELL)\s+@\s+(?P<entry>\d+\.?\d*)\s*[\n\r]+(?:S/L|SL|Stop\s*Loss)\s*(?P<sl>\d+\.?\d*)\s*[\n\r]+(?:T/P|TP|Take\s*Profit)\s*(?P<tp>\d+\.?\d*)
```

**Example Matches**:
```
✅
XAUUSD
BUY @ 2450.50
SL 2445.00
TP 2460.00

✅
XAU/USD
SELL @ 2450.50
S/L 2455.00
T/P 2440.00
```

---

### Format 4: Concise Format
**Pattern**: Hashtag-based, minimal formatting

```
#BUY 2450.50 SL2445 TP2460
#SELL 2450.50 SL2455 TP2440
```

**Regex**:
```regex
#(?P<type>BUY|SELL)\s+(?P<entry>\d+\.?\d*)\s+SL\s*(?P<sl>\d+\.?\d*)\s+TP\s*(?P<tp>\d+\.?\d*)
```

**Example Matches**:
- ✅ `#BUY 2450.50 SL2445 TP2460`
- ✅ `#SELL 2450.5 SL 2455 TP 2440`

---

## Invalid Signal Examples

These will be **rejected**:

```
❌ "BUY XAUUSD @ 2450" (missing SL and TP)
❌ "BUY GOLD @ 2450, SL: 2460, TP: 2445" (SL > Entry > TP, logic error)
❌ "SELL XAUUSD @ 2450, SL: 2440, TP: 2460" (TP < Entry < SL logic error for SELL)
❌ "BUY EURUSD @ 1.0850, SL: 1.0800, TP: 1.0900" (not XAUUSD)
```

---

## Validation Rules

After regex matching, signals are validated for:

1. **Type**: BUY or SELL ✓
2. **Entry, SL, TP**: All positive numbers ✓
3. **BUY Logic**: SL < Entry < TP ✓
4. **SELL Logic**: TP < Entry < SL ✓
5. **Price Range**: 1000 < prices < 3000 ✓

---

## Testing Your Patterns

Use this Python snippet to test:

```python
import re
from telegram_listener import SignalParser

# Test message
message = "BUY XAUUSD @ 2450.50, SL: 2445.00, TP: 2460.00"

# Parse
signal = SignalParser.parse_signal(message)

if signal:
    print(f"✅ Parsed: {signal.signal_type} @ {signal.entry_price}")
    print(f"   SL: {signal.stop_loss}, TP: {signal.take_profit}")
else:
    print("❌ Failed to parse")
```

---

## Adding New Patterns

To add a new signal format:

1. Add pattern to `PATTERNS` dict in `SignalParser`:
```python
'format_5': r'your_regex_pattern_here',
```

2. Test thoroughly with examples

3. Update this documentation

---

## Common Regex Symbols

| Symbol | Meaning |
|--------|---------|
| `\d` | Any digit (0-9) |
| `\.` | Literal dot |
| `\d+` | One or more digits |
| `\d*` | Zero or more digits |
| `\d+\.?\d*` | Number with optional decimal |
| `(?P<name>...)` | Named capture group |
| `\s` | Whitespace |
| `\s+` | One or more whitespace |
| `[\n\r]` | Newline or carriage return |
| `\|` | OR operator |
| `(?:...)` | Non-capturing group |
