name=docs/MOBILE_GUIDE.md
# 📱 Mobile GitHub Upload Guide

## For Users on Mobile Devices

This guide explains how to create and upload files to the CTRADERT_bot_Telegram repository using your mobile phone.

---

## Method 1: GitHub Web Browser (iOS/Android)

### Step 1: Go to Repository
1. Open **github.com** in your mobile browser
2. Search for "CTRADERT_bot_Telegram"
3. Tap on **YamenBadr19/CTRADERT_bot_Telegram**

### Step 2: Create a New File
1. Tap the **"+"** icon (top right)
2. Select **"Create new file"**

### Step 3: Add File Path & Content
1. In the **"Name your file..."** field, enter the path:
   ```
   python-brain/telegram_listener.py
   ```
   
2. In the editor below, paste the file content

3. Scroll down to **"Commit changes"**

4. Choose:
   - **"Commit directly to main branch"**

5. Tap **"Commit changes"**

### Step 4: Repeat for Each File
Repeat steps 2-5 for each file in your repository.

---

## Method 2: Working Copy (iOS)

### Installation
1. Open **App Store**
2. Search for "Working Copy"
3. Install (paid app ~$3)

### Clone Repository
1. Open Working Copy
2. Tap **"+"** (add repository)
3. Enter: `https://github.com/YamenBadr19/CTRADERT_bot_Telegram`
4. Tap "Clone"

### Create Files
1. Tap repository
2. Tap **"+"** (new file)
3. Enter filename: `python-brain/telegram_listener.py`
4. Paste content
5. Tap "Save"
6. Commit: Tap arrow → "Commit"
7. Message: "Add telegram_listener.py"
8. Tap "Commit & Push"

---

## Method 3: Termux (Android)

### Installation
1. Download **Termux** from F-Droid or Play Store
2. Open Termux
3. Update packages:
```bash
pkg update && pkg upgrade
```

### Install Git & Python
```bash
pkg install git python
```

### Clone Repository
```bash
cd ~
git clone https://github.com/YamenBadr19/CTRADERT_bot_Telegram.git
cd CTRADERT_bot_Telegram
```

### Create Files
```bash
# Create python-brain directory
mkdir -p python-brain

# Create requirements.txt
nano python-brain/requirements.txt
# Paste content, press Ctrl+X, then Y, then Enter

# Create config.py
nano python-brain/config.py
# Paste content, press Ctrl+X, then Y, then Enter

# Create telegram_listener.py
nano python-brain/telegram_listener.py
# Paste content, press Ctrl+X, then Y, then Enter
```

### Commit & Push
```bash
# Configure Git (first time only)
git config --global user.email "your.email@gmail.com"
git config --global user.name "YamenBadr19"

# Add files
git add python-brain/

# Commit
git commit -m "Add Python files"

# Push (will ask for GitHub token)
git push
```

### Generate GitHub Token
1. Go to github.com → Settings → Developer settings → Personal access tokens
2. Click "Generate new token"
3. Name: "Termux Access"
4. Check: `repo` scope
5. Click "Generate token"
6. Copy token
7. When Termux asks for password, paste token

---

## File Upload Checklist

### Root Level (Upload First)
- [ ] README.md
- [ ] LICENSE
- [ ] .gitignore

### python-brain/ Folder
- [ ] requirements.txt
- [ ] config.py
- [ ] telegram_listener.py
- [ ] market_analyzer.py
- [ ] signal_queue.py

### csharp-body/ Folder
- [ ] Blueprint_cBot.cs
- [ ] RiskManager.cs
- [ ] PositionMonitor.cs

### docs/ Folder
- [ ] SETUP_GUIDE.md
- [ ] REGEX_PATTERNS.md
- [ ] MOBILE_GUIDE.md

---

## Tips for Mobile Editing

### Keyboard Shortcuts (Termux)
- **Ctrl+C**: Cancel
- **Ctrl+X**: Exit nano editor
- **Y**: Confirm save
- **N**: Don't save
- **Ctrl+A**: Select all (GitHub web)
- **Ctrl+V**: Paste (GitHub web)

### Mobile Browser Tips
- Use **landscape mode** for easier editing
- Open in **desktop mode** for full interface
- Use **working copy** app for complex operations
- Test connection before long uploads

---

## Troubleshooting Mobile Issues

### "Connection timeout"
- Check your internet connection
- Try again in a few seconds
- Use WiFi instead of mobile data

### "File too large"
- Maximum single file: 100 MB
- GitHub web limit: 25 MB
- Use smaller files or compress

### "Authentication failed"
- Check GitHub username/email
- Regenerate Personal Access Token
- Make sure token has `repo` scope

### "Changes not showing"
- Refresh page (swipe down or F5)
- Clear browser cache
- Wait a few seconds for GitHub to sync

---

## Recommended Tools by Device

| Device | Best Option |
|--------|------------|
| **iOS** | Working Copy app |
| **Android** | Termux (advanced) or GitHub web |
| **iPad** | GitHub web + text editor combo |

---

## Quick Reference

### GitHub Web (All Devices)
```
1. github.com
2. Your repo
3. "Add file" → "Create new file"
4. Enter path and content
5. Commit changes
```

### Working Copy (iOS)
```
1. Clone repo
2. Tap "+"
3. New file with path
4. Commit & Push
```

### Termux (Android)
```
1. git clone
2. mkdir folders
3. nano file.py (edit)
4. git add .
5. git commit & push
```
