name=docs/SETUP_GUIDE.md
# 🚀 CTRADERT Bot - Complete Setup Guide

## Prerequisites

- Python 3.9 or higher
- Telegram account (personal, not bot)
- cTrader account (with demo first)
- GitHub account
- Code editor (VS Code recommended)

---

## Step 1: Get Telegram API Credentials

### 1.1 Create Telegram Application
1. Go to https://my.telegram.org/apps
2. Log in with your Telegram account
3. Click "Create a new application"
4. Fill in the form:
   - **App title**: CTRADERT Gold Bot
   - **Short name**: ctradert_gold
   - **URL**: (leave empty)
5. Click "Create application"

### 1.2 Copy Credentials
- Copy **API ID** (number)
- Copy **API Hash** (long string)
- Note your **Phone Number** (with country code: +1234567890)

---

## Step 2: Set Up Python Environment

### 2.1 Clone Repository
```bash
git clone https://github.com/YamenBadr19/CTRADERT_bot_Telegram.git
cd CTRADERT_bot_Telegram/python-brain
```

### 2.2 Create Virtual Environment
```bash
# macOS / Linux
python3 -m venv venv
source venv/bin/activate

# Windows
python -m venv venv
venv\Scripts\activate
```

### 2.3 Install Dependencies
```bash
pip install -r requirements.txt
```

---

## Step 3: Configure Telegram Credentials

### 3.1 Edit config.py
```bash
# Open config.py in your editor
nano config.py  # or use your preferred editor
```

### 3.2 Fill in Your Credentials
```python
TELEGRAM_API_ID = 12345678  # Your API ID
TELEGRAM_API_HASH = "abc123def456..."  # Your API Hash
TELEGRAM_PHONE = "+1234567890"  # Your phone with country code
```

### 3.3 Find Telegram Folder IDs

Run the helper script:
```bash
# Create find_folders.py temporarily
python3 << 'EOF'
from telethon import TelegramClient
import asyncio

async def main():
    api_id = int(input("Enter API ID: "))
    api_hash = input("Enter API Hash: ")
    phone = input("Enter Phone (+country): ")
    
    async with TelegramClient('temp_session', api_id, api_hash) as client:
        await client.start(phone=phone)
        print("\nYour folders:")
        async for dialog in client.iter_dialogs():
            print(f"ID: {dialog.entity.id} | Title: {dialog.title}")

asyncio.run(main())
EOF
```

### 3.4 Update Folder IDs
```python
# In config.py
SIGNALS_FOLDER_ID = 123456789  # From the output above
NEWS_FOLDER_ID = 987654321     # From the output above
```

---

## Step 4: Test Telegram Connection

```bash
python3 << 'EOF'
from telethon import TelegramClient
import asyncio
from config import TELEGRAM_API_ID, TELEGRAM_API_HASH, TELEGRAM_PHONE, SIGNALS_FOLDER_ID

async def test():
    client = TelegramClient('test_session', TELEGRAM_API_ID, TELEGRAM_API_HASH)
    await client.start(phone=TELEGRAM_PHONE)
    print("✅ Connected to Telegram!")
    
    # Try to access signal folder
    try:
        entity = await client.get_entity(SIGNALS_FOLDER_ID)
        print(f"✅ Signals folder accessible: {entity}")
    except Exception as e:
        print(f"❌ Error: {e}")
    
    await client.disconnect()

asyncio.run(test())
EOF
```

---

## Step 5: Start the Listener

```bash
python telegram_listener.py
```

**Expected Output:**
```
════════════════════════════════════════════════════════════════════
     CTRADERT BOT - TELEGRAM LISTENER (Gold XAUUSD)
     System Specification: Separation of Brain & Body
════════════════════════════════════════════════════════════════════

✅ Telegram client authenticated
✅ Signals folder accessible
✅ News folder accessible
════════════════════════════════════════════════════════════════════
🎯 TELEGRAM LISTENER ACTIVE
📡 Monitoring: Signals & News folders
⏰ Listening for incoming messages...
════════════════════════════════════════════════════════════════════
```

---

## Step 6: Deploy to Cloud (Optional)

### Using Railway.app
```bash
# Install Railway CLI
npm install -g @railway/cli

# Log in
railway login

# Deploy
railway up
```

---

## Troubleshooting

### "API ID not registered"
- Check you're using correct API credentials
- Ensure Telegram app was created successfully

### "Phone code is invalid"
- Enter the code Telegram sends via SMS/Telegram
- Don't include any dashes or spaces

### "Folder not found"
- Verify folder IDs are correct
- Make sure folders are in your main account
- Not bot-created folders

---

## Next Steps

1. **Test signal parsing**: Send test signals to your Signals folder
2. **Demo validation**: Deploy cBot to cTrader Demo Account
3. **Monitor**: Run for 7 days on demo before live
4. **Go live**: Switch to live account with minimum lot (0.01)
