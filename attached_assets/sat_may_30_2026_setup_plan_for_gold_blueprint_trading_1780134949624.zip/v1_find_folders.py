name=find_folders.py
from telethon import TelegramClient
import asyncio

async def main():
    async with TelegramClient('session', API_ID, API_HASH) as client:
        async for dialog in client.iter_dialogs():
            print(f"{dialog.entity.id}: {dialog.title}")

asyncio.run(main())