name=telegram_listener.py
"""
The Radar: Telegram Userbot Listener & Signal Parser
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Connects to Telegram using MTProto API via Telethon.
Monitors Signal & News folders for Gold (XAUUSD) signals.
Parses regex patterns and streams to market_analyzer.py
"""

import asyncio
import re
import logging
from datetime import datetime
from typing import Optional, Dict, List, Tuple
from dataclasses import dataclass
from telethon import TelegramClient, events
from telethon.tl.types import PeerChannel, PeerChat, UpdateNewChannelMessage
import json

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# CONFIGURATION & LOGGING
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('telegram_listener.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Import configuration (will be created separately)
try:
    from config import TELEGRAM_API_ID, TELEGRAM_API_HASH, TELEGRAM_PHONE, \
        SIGNALS_FOLDER_ID, NEWS_FOLDER_ID, SESSION_NAME
except ImportError:
    logger.error("config.py not found. Please create config.py with Telegram credentials.")
    raise


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# DATA MODELS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@dataclass
class TradingSignal:
    """Parsed Gold Trading Signal"""
    timestamp: datetime
    signal_type: str  # "BUY" or "SELL"
    entry_price: float
    stop_loss: float
    take_profit: float
    source_folder: str  # "SIGNALS" or "NEWS"
    raw_message: str
    confidence_score: float = 1.0  # Placeholder for AI scoring
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization"""
        return {
            'timestamp': self.timestamp.isoformat(),
            'signal_type': self.signal_type,
            'entry_price': self.entry_price,
            'stop_loss': self.stop_loss,
            'take_profit': self.take_profit,
            'source_folder': self.source_folder,
            'raw_message': self.raw_message,
            'confidence_score': self.confidence_score
        }


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# SIGNAL PARSER (REGEX ENGINE)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class SignalParser:
    """
    Extracts XAUUSD trading signals using regex patterns.
    Matches multiple signal formats for flexibility.
    """
    
    # Regex patterns for different signal formats
    PATTERNS = {
        # Format 1: "BUY XAUUSD @ 2450.50, SL: 2445.00, TP: 2460.00"
        'format_1': r'(?P<type>BUY|SELL)\s+(?:XAUUSD|XAU/USD)\s+@\s+(?P<entry>\d+\.?\d*),?\s+(?:SL|Stop\s*Loss):\s*(?P<sl>\d+\.?\d*),?\s+(?:TP|Take\s*Profit):\s*(?P<tp>\d+\.?\d*)',
        
        # Format 2: "BUY\n2450.50\nSL: 2445.00\nTP: 2460.00"
        'format_2': r'(?P<type>BUY|SELL)\s*(?:XAUUSD|XAU/USD)?\s*[\n\r]+(?P<entry>\d+\.?\d*)\s*[\n\r]+(?:SL|Stop\s*Loss):\s*(?P<sl>\d+\.?\d*)\s*[\n\r]+(?:TP|Take\s*Profit):\s*(?P<tp>\d+\.?\d*)',
        
        # Format 3: "XAUUSD\nBUY @ 2450.50\nS/L 2445.00\nT/P 2460.00"
        'format_3': r'(?:XAUUSD|XAU/USD)\s*[\n\r]+(?P<type>BUY|SELL)\s+@\s+(?P<entry>\d+\.?\d*)\s*[\n\r]+(?:S/L|SL|Stop\s*Loss)\s*(?P<sl>\d+\.?\d*)\s*[\n\r]+(?:T/P|TP|Take\s*Profit)\s*(?P<tp>\d+\.?\d*)',
        
        # Format 4: Concise format "#BUY 2450.50 SL2445 TP2460"
        'format_4': r'#(?P<type>BUY|SELL)\s+(?P<entry>\d+\.?\d*)\s+SL\s*(?P<sl>\d+\.?\d*)\s+TP\s*(?P<tp>\d+\.?\d*)',
    }
    
    @staticmethod
    def parse_signal(message: str) -> Optional[TradingSignal]:
        """
        Attempt to parse a signal from message text.
        Returns TradingSignal if successful, None otherwise.
        """
        message = message.strip()
        
        # Check if message contains XAUUSD references
        if 'XAUUSD' not in message.upper() and 'XAU/USD' not in message.upper():
            return None
        
        # Try each regex pattern
        for pattern_name, pattern in SignalParser.PATTERNS.items():
            match = re.search(pattern, message, re.IGNORECASE | re.MULTILINE)
            
            if match:
                try:
                    signal_type = match.group('type').upper()
                    entry_price = float(match.group('entry'))
                    stop_loss = float(match.group('sl'))
                    take_profit = float(match.group('tp'))
                    
                    # Validation: Entry should be between SL and TP
                    if signal_type == 'BUY':
                        if not (stop_loss < entry_price < take_profit):
                            logger.warning(f"Invalid BUY signal: SL({stop_loss}) < Entry({entry_price}) < TP({take_profit}) not satisfied")
                            continue
                    else:  # SELL
                        if not (take_profit < entry_price < stop_loss):
                            logger.warning(f"Invalid SELL signal: TP({take_profit}) < Entry({entry_price}) < SL({stop_loss}) not satisfied")
                            continue
                    
                    logger.info(f"✓ Signal parsed ({pattern_name}): {signal_type} @ {entry_price}")
                    
                    return TradingSignal(
                        timestamp=datetime.utcnow(),
                        signal_type=signal_type,
                        entry_price=entry_price,
                        stop_loss=stop_loss,
                        take_profit=take_profit,
                        source_folder="SIGNALS",
                        raw_message=message
                    )
                
                except (ValueError, AttributeError) as e:
                    logger.error(f"Error parsing signal with {pattern_name}: {e}")
                    continue
        
        return None


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# TELEGRAM LISTENER
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class TelegramListener:
    """
    Connects to Telegram and monitors Signal/News folders.
    Streams parsed signals to market_analyzer.py via queue/API.
    """
    
    def __init__(self):
        self.client = TelegramClient(SESSION_NAME, TELEGRAM_API_ID, TELEGRAM_API_HASH)
        self.signals_queue: List[TradingSignal] = []
        self.news_queue: List[str] = []
        self.signals_folder_id = SIGNALS_FOLDER_ID
        self.news_folder_id = NEWS_FOLDER_ID
        
        logger.info("TelegramListener initialized")
    
    async def start(self):
        """Initialize and authenticate with Telegram"""
        await self.client.start(phone=TELEGRAM_PHONE)
        logger.info("✓ Telegram client started and authenticated")
        
        # Verify folder accessibility
        try:
            signals_entity = await self.client.get_entity(self.signals_folder_id)
            news_entity = await self.client.get_entity(self.news_folder_id)
            logger.info(f"✓ Signals Folder: {signals_entity.title if hasattr(signals_entity, 'title') else 'Found'}")
            logger.info(f"✓ News Folder: {news_entity.title if hasattr(news_entity, 'title') else 'Found'}")
        except Exception as e:
            logger.error(f"Error accessing folders: {e}")
            raise
    
    async def listen_signals(self):
        """
        Monitor Signals folder for incoming messages.
        Parse and queue valid XAUUSD signals.
        """
        @self.client.on(events.NewMessage(chats=self.signals_folder_id))
        async def handle_signal(event):
            message_text = event.message.message
            logger.info(f"[SIGNALS] New message: {message_text[:100]}...")
            
            # Parse signal
            signal = SignalParser.parse_signal(message_text)
            
            if signal:
                self.signals_queue.append(signal)
                logger.info(f"✓ Signal queued: {signal.signal_type} @ {signal.entry_price}")
                
                # TODO: Stream to market_analyzer.py via:
                # - Option A: Queue/Pub-Sub system (Redis, RabbitMQ)
                # - Option B: HTTP API endpoint
                # - Option C: Async task queue (Celery)
                await self.stream_signal_to_analyzer(signal)
            else:
                logger.warning("Message does not match any signal pattern")
        
        logger.info("Listening to Signals folder...")
    
    async def listen_news(self):
        """
        Monitor News folder for breaking news.
        Stream raw text to market_analyzer.py for sentiment analysis.
        """
        @self.client.on(events.NewMessage(chats=self.news_folder_id))
        async def handle_news(event):
            message_text = event.message.message
            logger.info(f"[NEWS] Breaking news: {message_text[:100]}...")
            
            self.news_queue.append(message_text)
            
            # TODO: Stream to market_analyzer.py for AI sentiment analysis
            await self.stream_news_to_analyzer(message_text)
        
        logger.info("Listening to News folder...")
    
    async def stream_signal_to_analyzer(self, signal: TradingSignal):
        """
        Stream parsed signal to market_analyzer.py.
        
        PLACEHOLDER: Replace with actual streaming mechanism:
        - Option A: Write to Redis queue
        - Option B: POST to HTTP API
        - Option C: Write to local queue file
        """
        logger.info(f"→ Streaming signal to analyzer: {signal.to_dict()}")
        
        # TODO: Implement streaming
        # Example with Redis:
        # import redis
        # r = redis.Redis(host='localhost', port=6379, db=0)
        # r.rpush('signal_queue', json.dumps(signal.to_dict()))
        
        # Example with HTTP:
        # import aiohttp
        # async with aiohttp.ClientSession() as session:
        #     async with session.post('http://localhost:5000/signal', json=signal.to_dict()) as resp:
        #         return await resp.json()
    
    async def stream_news_to_analyzer(self, news_text: str):
        """
        Stream news text to market_analyzer.py for sentiment analysis.
        
        PLACEHOLDER: Replace with actual streaming mechanism.
        """
        logger.info(f"→ Streaming news to analyzer: {news_text[:50]}...")
        
        # TODO: Implement streaming
        # Similar pattern as stream_signal_to_analyzer()
    
    async def run(self):
        """Main listener loop"""
        await self.start()
        await self.listen_signals()
        await self.listen_news()
        
        logger.info("━" * 60)
        logger.info("🎯 TELEGRAM LISTENER ACTIVE")
        logger.info("Monitoring: Signals & News folders")
        logger.info("━" * 60)
        
        # Keep listener running
        await self.client.run_until_disconnected()


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# MAIN EXECUTION
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

async def main():
    """Initialize and run the Telegram listener"""
    listener = TelegramListener()
    try:
        await listener.run()
    except KeyboardInterrupt:
        logger.info("Listener interrupted by user")
    except Exception as e:
        logger.error(f"Critical error: {e}", exc_info=True)
    finally:
        await listener.client.disconnect()
        logger.info("Telegram client disconnected")


if __name__ == "__main__":
    asyncio.run(main())