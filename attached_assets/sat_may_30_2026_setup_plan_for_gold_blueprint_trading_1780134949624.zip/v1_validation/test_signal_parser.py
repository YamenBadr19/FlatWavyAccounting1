name=validation/test_signal_parser.py
"""
Unit tests for signal parser regex patterns
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Tests all 4 signal formats and edge cases
"""

import unittest
import sys
sys.path.insert(0, '../python-brain')

from telegram_listener import SignalParser, TradingSignal


class TestSignalParser(unittest.TestCase):
    """Test cases for signal parsing"""
    
    def test_format_1_inline(self):
        """Test Format 1: Inline format"""
        message = "BUY XAUUSD @ 2450.50, SL: 2445.00, TP: 2460.00"
        signal = SignalParser.parse_signal(message)
        
        self.assertIsNotNone(signal)
        self.assertEqual(signal.signal_type, "BUY")
        self.assertEqual(signal.entry_price, 2450.50)
        self.assertEqual(signal.stop_loss, 2445.00)
        self.assertEqual(signal.take_profit, 2460.00)
    
    def test_format_2_multiline(self):
        """Test Format 2: Multi-line format"""
        message = """BUY
2450.50
SL: 2445.00
TP: 2460.00"""
        signal = SignalParser.parse_signal(message)
        
        self.assertIsNotNone(signal)
        self.assertEqual(signal.signal_type, "BUY")
        self.assertEqual(signal.entry_price, 2450.50)
    
    def test_format_3_alternative(self):
        """Test Format 3: Alternative layout"""
        message = """XAUUSD
BUY @ 2450.50
S/L 2445.00
T/P 2460.00"""
        signal = SignalParser.parse_signal(message)
        
        self.assertIsNotNone(signal)
        self.assertEqual(signal.signal_type, "BUY")
    
    def test_format_4_concise(self):
        """Test Format 4: Concise format"""
        message = "#BUY 2450.50 SL2445 TP2460"
        signal = SignalParser.parse_signal(message)
        
        self.assertIsNotNone(signal)
        self.assertEqual(signal.signal_type, "BUY")
    
    def test_sell_signal(self):
        """Test SELL signal"""
        message = "SELL XAUUSD @ 2450.50, SL: 2455.00, TP: 2440.00"
        signal = SignalParser.parse_signal(message)
        
        self.assertIsNotNone(signal)
        self.assertEqual(signal.signal_type, "SELL")
        self.assertEqual(signal.entry_price, 2450.50)
    
    def test_invalid_signal_missing_xauusd(self):
        """Test rejection: Missing XAUUSD symbol"""
        message = "BUY @ 2450.50, SL: 2445.00, TP: 2460.00"
        signal = SignalParser.parse_signal(message)
        
        self.assertIsNone(signal)
    
    def test_invalid_signal_bad_logic_buy(self):
        """Test rejection: Bad BUY logic (SL > Entry)"""
        message = "BUY XAUUSD @ 2450.50, SL: 2455.00, TP: 2460.00"
        signal = SignalParser.parse_signal(message)
        
        self.assertIsNone(signal)
    
    def test_invalid_signal_bad_logic_sell(self):
        """Test rejection: Bad SELL logic (TP > Entry)"""
        message = "SELL XAUUSD @ 2450.50, SL: 2445.00, TP: 2440.00"
        signal = SignalParser.parse_signal(message)
        
        # This should technically parse but warn
        # Actual behavior depends on implementation


if __name__ == '__main__':
    unittest.main()